# LIBERO double moka pot: guided recovery SFT candidate

The original frozen pi0.5 rollout timed out after the first pot was placed. The
paired branches restore the original state at step 210 by resetting, settling
10 steps and replaying the saved action prefix. They share the same snapshot
and policy seed 42. The control keeps the original instruction and times out.
The guided branch switches to the original instruction after lifting the
remaining pot at step 417 and reaches native task success at step 498.

- frames.parquet contains 288 transitions from steps 210 to 498. Each row
  indexes the matching observation and next observation in both camera videos.
- agentview.mp4 and wrist.mp4 each contain 289 frames at 20 FPS, including the
  final observation. Images are 256 x 256 with official orientation applied.
- snapshot.npz contains the initial state, action prefix, checked physics state
  and both camera frames. Use replay of the prefix to restore controller state.
- operator-tags.json is a manual visual annotation by Codex. It is pending
  independent human expert review and is not counted toward the 100 accepted examples.
- The WM predicts five-step state changes in shadow and is refit using measured
  recovery transitions. It uses privileged simulator object poses; it neither
  generates video nor selects the executed actions. Cosmos was not loaded.

The archive uses Parquet plus aligned MP4 sources. Export to the pinned
LeRobot/OpenPI dataset version before invoking a full training recipe.
